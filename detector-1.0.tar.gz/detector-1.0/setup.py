from setuptools.command.install import install
from setuptools import setup, find_packages
import os
import sys
from os.path import join, dirname
python_v=sys.version
python_v=float(python_v[:3])
if python_v<3.8:
    print ("wrong python version number. must be >3.7")
    sys.exit()
import app

print ("python version is %s" % python_v)
class CustomInstallCommand(install):

  def run(self):
    install.run(self)
    current_dir_path = os.path.dirname(os.path.realpath(__file__))
    create_service_script_path = os.path.join(current_dir_path, 'app',  'create_service.sh')
    main_script = os.path.join(current_dir_path, 'detector.py')
    os.system("chmod +x %s" % create_service_script_path)
    os.system("chmod +x "+main_script)
    os.system("%s %s" % (create_service_script_path, python_v))

setup(
    name='detector',
    version=app.__version__,
    packages=['','app','app/detector'],
    long_description=open(join(dirname(__file__), 'README.md')).read(),
    install_requires=[
        'quart'
    ],
    scripts=['detector.py'],
    cmdclass={'install': CustomInstallCommand},
    include_package_data=True
)


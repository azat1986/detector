# Детектор аудио
# требования: Asterisk с поддержкой ARI, python не ниже 3.8

### 1. Установить виртуальное окружение python3 venv в директории проекта.

```
sudo tar xvf detector-1.0.tar.gz
cd detector-1.0
sudo python setup.py install
```

# В настройках ввести данные для подключения к Asterisk. Прописать названия endpoint, context и данные для подключения к модулю. В extensions астериска прописать названия приложения для detector
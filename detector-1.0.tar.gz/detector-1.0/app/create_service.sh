echo "$1"
echo "[Unit]
Description=detector

[Service]
Type=simple
ExecStart=/usr/local/bin/python$1 /usr/local/bin/detector.py
Restart=always

[Install]
WantedBy=multi-user.target
" > /lib/systemd/system/detector.service
chown root:root /lib/systemd/system/detector.service


systemctl daemon-reload

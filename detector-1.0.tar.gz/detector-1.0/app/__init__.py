############################
###      CREATED BY     ####
### © Azat Zakirov, 2022 ###
############################
__version__ = '1.0'
import os
from quart import Quart
import logging
from quart.logging import serving_handler, default_handler, getLogger
from logging.handlers import TimedRotatingFileHandler
import asyncio

def create_app():
    """ Создаем экземпляр приложения.
    main.py
    :return: app
    """
    app = Quart(__name__)
    app.config.from_object('config.ProductionConfig')
    # строка формата сообщения
    _log_format = f"%(asctime)s - [%(levelname)s] - [%(threadName)s] - %(name)s - (%(filename)s).%(funcName)s(%(lineno)d) - %(message)s"
    logger = getLogger('quart.serving')  # __name__ quart.app quart.serving
    logger.propagate = False
    # пишет события логгера
    file_handler = TimedRotatingFileHandler(app.config.get('ARI_LOG'), when='h', interval=1, backupCount=10)
    file_handler.setFormatter(logging.Formatter(fmt=_log_format))
    # добавляем serving_handler в регистратор
    # вывод в консоль
    app.logger.propagate = False
    app.logger.addHandler(file_handler)
    logger.addHandler(file_handler)
    getLogger('quart.app').removeHandler(default_handler)
    getLogger('quart.serving').removeHandler(serving_handler)
    import app.detector.controllers as detector
    app.register_blueprint(detector.module)
    return app

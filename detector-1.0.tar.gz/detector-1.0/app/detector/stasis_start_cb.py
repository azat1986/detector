############################
###      CREATED BY     ####
### © Azat Zakirov, 2022 ###
############################

from quart import current_app
from aioari import Client
from aioari.model import Channel
from typing import Dict
from aiohttp.web_exceptions import HTTPError, HTTPNotFound
import asyncio
import uuid
import re
from .state_change import *

async def snoop_recording_before(client: Client, channel: Channel, snoop_channel: Channel,dest) -> None:
    """ Запись речи до поднятия трубки абонентом """
    try:
        current_app.config.get('RECORDING')[channel.id] = await snoop_channel.record(
            name=f'{current_app.config.get("ARI_DIR_RECORD")}/before/{dest}',
            format='ogg',
            ifExists='overwrite'
        )
        current_app.logger.info(f"Запись аудио канала начата")
    except HTTPError as e:
        if e.response.status_code != HTTPNotFound.status_code:
            raise

async def stasis_start_cb_task(channel_obj: Channel, event: Dict, client: Client) -> None:
    """ Асинхронная задача для события  """
    current_app.logger.info(f"event {event}")
    obj = event.get('channel')
    dest = obj.get('dialplan')
    dest = dest.get('exten')
    caller = obj.get('caller')
    caller = caller.get('number')
    channel_id = obj.get('id')
    if channel_id[:3]!='red' and channel_id[:5]!='snoop' and event['channel']['state'] != 'Up':
        channel = await client.channels.get(channelId=channel_id)
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:  # if cleanup: 'RuntimeError: There is no current event loop..'
            loop = None
        if loop and loop.is_running():
            loop.create_task(stasis_start_cb(channel, event, client,caller,dest))

async def stasis_start_cb(channel: Channel, event: Dict, client: Client,caller,dest) -> None:
    """ Событие stasis_start_cb - получен звонок """
    uid = str(uuid.uuid4())
    outgoing = await client.channels.create(
        endpoint=f"PJSIP/{dest}\@{current_app.config['ENDPOINT']}",
        app=current_app.config.get('ARI_APP'),
        channelId=f'red{uid}'
    )
    bridge = await client.bridges.create(type='mixing')
    current_app.config['DATA'][outgoing.id]={}
    current_app.config['DATA'][outgoing.id]['caller']=caller
    current_app.config['DATA'][outgoing.id]['dest']=dest
    current_app.config['BRIDGES'][outgoing.id]=bridge.id
    current_app.logger.info(f"bridge {bridge.id}")
    current_app.config['CHANNELS_IN'][outgoing.id]=channel.id
    current_app.config['CHANNELS_OUT'][channel.id]=outgoing.id
    await client.bridges.addChannel(bridgeId=bridge.id, channel=[channel.id, outgoing.id])
    await client.channels.dial(channelId=outgoing.id, caller=channel.id)
    snoop_id = f"snoop_{outgoing.id}"
    snoop_channel = await outgoing.snoopChannelWithId(
        snoopId=snoop_id,
        app=current_app.config.get('ARI_APP'),
        spy='in',
        whisper='none'
    )
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:  # if cleanup: 'RuntimeError: There is no current event loop..'
        loop = None
    if loop and loop.is_running():
        loop.create_task(snoop_recording_before(client, outgoing,snoop_channel,dest))

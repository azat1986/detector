############################
###      CREATED BY     ####
### © Azat Zakirov, 2022 ###
############################

from quart import Blueprint, current_app, request
import asyncio
import aioari
from .stasis_start_cb import *
from .state_change import *
from .on_recording_finished import *

module = Blueprint('detector', __name__, url_prefix='/detector')

@module.route('/status', methods=['GET'])
async def status() -> str:
    """ Получаем статус пинга
    :return: ping status
    """
    if request.args['type']=='start' and current_app.config.get('START')==0:
        current_app.config['START']=1
        if current_app.config.get('ARI_CLIENT') == {}:
            current_app.logger.info('Создаем коннект к астериск')
            client = await aioari.connect(
                current_app.config.get('ARI_URL'),
                current_app.config.get('ARI_USER'),
                current_app.config.get('ARI_PASSWORD')
            )
            current_app.config.get('ARI_CLIENT')[0] = client
        else:
            client = current_app.config.get('ARI_CLIENT')[0]
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:  # if cleanup: 'RuntimeError: There is no current event loop..'
            loop = None
        if loop and loop.is_running():
            current_app.logger.info("Создаем APP")
            loop.create_task(client.run(apps=f"{current_app.config.get('ARI_APP')}"))
            client.on_channel_event('StasisStart', stasis_start_cb_task, client)
            client.on_channel_event('ChannelStateChange', state_change_task, client)
            client.on_event('BridgeDestroyed', bridge_destr)
            client.on_channel_event('StasisEnd', stasis_end, client)
            client.on_channel_event('ChannelDestroyed', destroyed_task, client)
            client.on_live_recording_event('RecordingFinished', on_recording_finished_task, client)
    return "{\"status\":\"ok\"}"

############################
###      CREATED BY     ####
### © Azat Zakirov, 2022 ###
############################

from quart import current_app
from aioari import Client
from aioari.model import Channel
from typing import Dict
import aiohttp
from aiohttp.web_exceptions import HTTPError, HTTPNotFound
from .send_detector import *
import asyncio

async def safe_hangup(channel_id) -> None:
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:  # if cleanup: 'RuntimeError: There is no current event loop..'
        loop = None
    if loop and loop.is_running():
        loop.create_task( safe_hangup_t(channel_id))

async def safe_hangup_t(channel_id) -> None:
    """ Принудительное разрушение канала """
    client=current_app.config.get('ARI_CLIENT')[0]
    try:
        channel = await client.channels.get(channelId=channel_id)
        current_app.logger.info(f"CHANNEL_SAFE_HANGUP: {channel}")
        await channel.hangup()
    except HTTPError as e:
        # Ignore 404's, since channels can go away before we get to them
        if e.response.status_code != HTTPNotFound.status_code:
            raise

async def on_recording_finished_task(live_recording: Dict, event: Dict, client: Client) -> None:
    """ Асинхронная задача для события окончания записи """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:  # if cleanup: 'RuntimeError: There is no current event loop..'
        loop = None
    if loop and loop.is_running():
        loop.create_task(on_recording_finished(live_recording, event, client))

async def on_recording_finished(live_recording: Dict, event: Dict, client: Client) -> None:
    """ Событие окончания записи речи. Распознавание речи детектором """
    ab=event.get('recording').get('name')
    channel__id = event.get('recording').get('target_uri').replace('channel:', '')
    if 'before' in ab or 'after' in ab:
        snoop_channel_id = channel__id
        channel_id = channel__id[6:]
        if 'before' in ab:
            await send_detector( channel_id, channel__id, snoop_channel_id,'before')
        elif 'after' in ab:
            await send_detector( channel_id, channel__id, snoop_channel_id,'after')
        try: 
            decoded_data = current_app.config.get('ARI_DECODED_DATA')[channel_id]
        except:
            pass
        else:
            try:
                current_app.logger.info(f"ID {channel_id} => {decoded_data}")
                if decoded_data.get("success"):
                    detector = decoded_data.get("answer_machine")
                else:
                    detector = False
                if detector == True:
                    try:
                        await safe_hangup(channel_id)
                    except HTTPError as e:
                        if e.response.status_code != HTTPNotFound.status_code:
                            raise
                else:
                    channel = await client.channels.get(channelId=channel_id)
                    await channel.continueInDialplan(current_app.config.get('ENDPOINT'),current_app.config.get('CONTEXT'))
            except:
                pass


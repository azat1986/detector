############################
###      CREATED BY     ####
### © Azat Zakirov, 2022 ###
############################

from quart import current_app
from aioari import Client
from aioari.model import Channel
import aiohttp
from aiohttp.web_exceptions import HTTPError, HTTPNotFound
from typing import AnyStr
import random
import aiofiles
async def send_detector(channel_id: AnyStr, channel__id: AnyStr, snoop_channel_id: AnyStr,ab: AnyStr):
    try:
        if ab=='before':
            file=f'{current_app.config.get("ASTERISK_RECORDING_PATH")}{current_app.config.get("ARI_DIR_RECORD")}/before/{current_app.config["DATA"][channel_id]["dest"]}.ogg'
        elif ab=='after':
            file=f'{current_app.config.get("ASTERISK_RECORDING_PATH")}{current_app.config.get("ARI_DIR_RECORD")}/after/{current_app.config["DATA"][channel_id]["dest"]}.ogg'

        async with aiofiles.open(file, mode='rb') as f:
            data = await f.read()
        connector = aiohttp.TCPConnector(limit=None)
        async with aiohttp.ClientSession(connector=connector) as session_api:
            address = current_app.config.get("DETECTOR_URL")
            if ab=='before':
                url=f'{address}?before=1'
            elif ab=='after':
                url=f'{address}?before=0'
            async with session_api.post(
                    url=url,
                    data=data,
                    params={'login': current_app.config.get("LOGIN"),'password': current_app.config.get("PASSWORD")}
            ) as response_post:
                decoded_data = await response_post.json()
        await session_api.close()
        current_app.config.get('ARI_DECODED_DATA')[channel_id] = decoded_data
    except KeyError:
        current_app.logger.info(f"ID => Ключ не существует send_d")

############################
###      CREATED BY     ####
### © Azat Zakirov, 2022 ###
############################

from quart import current_app
from aioari import Client
from aioari.model import Channel
from typing import Dict
from typing import AnyStr
import aiohttp
import asyncio
import time
from datetime import datetime
from aiohttp.web_exceptions import HTTPError, HTTPNotFound

async def stop_recording(name: AnyStr, client: Client, channel: Channel,ab: AnyStr) -> None:
    """ Принудительное прекращение воспроизведения файла для события dtmf """
    try:
        if ab=='before':
            try:
                recording = current_app.config.get('RECORDING')[channel.id]
            except:
                pass
            else:
                await recording.stop()
        else:
            snoop_id = str(f'snoop_{channel.id}')
            try:
                snoop_record = await client.channels.get(channelId=snoop_id)
            except:
                pass
            else:
                current_app.config.get('RECORDING')[channel.id] = await snoop_record.record(
                    name=name,
                    format='ogg',
                    ifExists='overwrite'
                )
                await asyncio.sleep(3)
                try:
                    recording = current_app.config.get('RECORDING')[channel.id]
                except:
                    pass
                else:
                    await recording.stop()
    except HTTPError as e:
        if e.response.status_code != HTTPNotFound.status_code:
            raise

async def bridge_destr(bridgeId) -> None:
    current_app.logger.info(f"Bridge {bridgeId}")

async def stasis_end(channel: Channel, event: Dict, client: Client) -> None:
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:  # if cleanup: 'RuntimeError: There is no current event loop..'
        loop = None

    if loop and loop.is_running():
        loop.create_task(stasisend(channel, event, client))

async def stasisend(channel: Channel, event: Dict, client: Client) -> None:
    try:
        current_app.config['CHANNELS_OUT'][channel.id]
    except:
        pass
    else:
        bridge = await client.bridges.get(bridgeId=current_app.config['BRIDGES'][current_app.config['CHANNELS_OUT'][channel.id]])
        await bridge.destroy()
        try:
            channel1 = await client.channels.get(channelId=current_app.config['CHANNELS_OUT'][channel.id])
        except:
            pass
        else:
            await channel1.hangup()
        del current_app.config['CHANNELS_IN'][current_app.config['CHANNELS_OUT'][channel.id]]


async def destroyed_task(channel: Channel, event: Dict, client: Client) -> None:
    #current_app.logger.info(f"ID {event}")
    """ Асинхронная задача для события смены статуса звонка"""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:  # if cleanup: 'RuntimeError: There is no current event loop..'
        loop = None

    if loop and loop.is_running():
        loop.create_task(destroyed(channel, event, client))


async def destroyed(channel: Channel, event: Dict, client: Client) -> None:
    current_app.logger.info(f"ID {event}")
    current_app.logger.info(f"destroyed {channel.id}")
    try:
        bridge = await client.bridges.get(bridgeId=current_app.config['BRIDGES'][channel.id])
    except:
        current_app.logger.info(f"bridgeId НЕ СУЩЕСТВУЕТ {current_app.config['BRIDGES'][channel.id]}")
    else:
        current_app.logger.info(f"bridgeId {current_app.config['BRIDGES'][channel.id]}")
        await bridge.destroy()
    if event.get('cause') == 0:
        status = 'timeout'
        dlr='EXPIRED'
    elif event.get('cause') == 1:
        status = 'no_answer'
        dlr='UNDELIV'
    elif event.get('cause') == 17:
        status = 'busy'
        dlr='REJECTD'
    elif event.get('cause') == 6:
        status = 'timeout'
        dlr='EXPIRED'
    elif event.get('cause') == 18:
        status = 'timeout'
        dlr='EXPIRED'
    elif event.get('cause') == 16:
        status = 'normal'
        dlr='DELIVERED'
    elif event.get('cause') == 21:
        status = 'rejected'
        dlr='REJECTD'
    elif event.get('cause') == 42:
        status = 'congestion'
        dlr='UNDELIV'
    elif event.get('cause') == 31:
        status = 'normal_unspecified'
        dlr='UNDELIV'
    elif event.get('cause') == 19:
        status = 'unallocated'
        dlr='UNDELIV'
    elif event.get('cause') == 38:
        status = 'number_incomplete'
        dlr='UNKNOWN'
    elif event.get('cause') == 27:
        status = 'failure'
        dlr='UNKNOWN'
    else:
        status = 'failure'
        dlr='UNKNOWN'

    detector=False
    try:
        current_app.config['CHANNELS_IN'][channel.id]
    except:
        current_app.logger.info(f"Канал с клиентом не существует")
        #если канал с клиентом не существует
        try:
            channel = await client.channels.get(channelId=channel.id)
        except:
            current_app.logger.info(f"Канал с пользователем не существует")
        else:
            await channel.hangup()
    else:
        #разрушаем канал с клиентом
        del current_app.config['CHANNELS_OUT'][current_app.config['CHANNELS_IN'][channel.id]]
        channel1 = await client.channels.get(channelId=current_app.config['CHANNELS_IN'][channel.id])
        try:
            decoded_data = current_app.config.get('ARI_DECODED_DATA')[channel.id]
        except:
            current_app.logger.info(f"decoded_data не существует. статус {status}")
            await channel1.hangup(reason=status)
        else:
            if decoded_data.get("success"):
                detector = decoded_data.get("answer_machine")
            else:
                detector = False
            if detector == True:
                await channel1.hangup(reason='answered_elsewhere')
            else:
                await channel1.hangup(reason=status)
    del current_app.config['DATA'][channel.id]


async def state_change_task(channel: Channel, event: Dict, client: Client) -> None:
    current_app.logger.info(f"ID {event}")
    """ Асинхронная задача для события смены статуса звонка"""
    if channel.id[:3]=='red':
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:  # if cleanup: 'RuntimeError: There is no current event loop..'
            loop = None

        if loop and loop.is_running():
            loop.create_task(state_change(channel, event, client))


async def state_change(outgoing: Channel, event: Dict, client: Client) -> None:
    """ Событие смены статуса звонка - абонент взял трубку  """
    if event['channel']['state'] == 'Up' and outgoing.id not in current_app.config['CHANNELS_OUT']:
        current_app.config['DATA'][outgoing.id]['up']=time.time()
        channel_id= current_app.config['CHANNELS_IN'][outgoing.id]
        channel = await client.channels.get(channelId=channel_id)

        await channel.answer()
        name=f'{current_app.config.get("ARI_DIR_RECORD")}/before/{current_app.config["DATA"][outgoing.id]["dest"]}'
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:  # if cleanup: 'RuntimeError: There is no current event loop..'
            loop = None
        if loop and loop.is_running():
            loop.create_task(stop_recording(name, client, outgoing,'before'))
            name=f'{current_app.config.get("ARI_DIR_RECORD")}/after/{current_app.config["DATA"][outgoing.id]["dest"]}'
            loop.create_task(stop_recording(name, client, outgoing,'after'))
        else:
            current_app.logger.info(f"ID {outgoing.id} => STATE_CHANGE LOOP не запущен!")

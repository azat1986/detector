class Config(object):
    # Определяет, включен ли режим отладки
    # В случае если включен, quart будет показывать
    # подробную отладочную информацию. Если выключен -
    # - 500 ошибку без какой либо дополнительной информации.
    DEBUG = True
    # URL для соединения с Asterisk
    ARI_URL = 'http://127.0.0.1:8088/'
    # Пользователь ARI
    ARI_USER = ''
    # Пароль пользователя ARI
    ARI_PASSWORD = ''
    # Соединение с Asterisk
    ARI_CLIENT = {}

    # Название приложения Asterisk
    ARI_APP = 'stasis-detector'  
    # Хранилище live_recording
    RECORDING = {}
    # Хранилище мостов
    BRIDGES = {}
    #Хранилище данных звонков
    DATA = {}
    #Хранилище входящих каналов
    CHANNELS_OUT = {}
    #Хранилище исходящих каналов
    CHANNELS_IN = {}
    # Директория для записей детектора
    ARI_DIR_RECORD = 'detector_record'
    # Путь к дериктории для записей
    ASTERISK_RECORDING_PATH = '/var/spool/asterisk/recording/'
    # Для хранения декодированых данных детектора
    ARI_DECODED_DATA = {}
    # PJSIP endpint section name
    ENDPOINT = ''
    # DIALPLAN name
    CONTEXT = ''

    #метка старта
    START = 0


    # Логин и пароль для запроса на детектор
    LOGIN = ''
    PASSWORD = ''
    #адресс детектора
    DETECTOR_URL = 'https://sms.intellin.ru/detector.cgi'
    # Лог файл
    ARI_LOG = '/var/log/detector_debug.log'



class ProductionConfig(Config):
    DEBUG = True
    ENV = 'production'


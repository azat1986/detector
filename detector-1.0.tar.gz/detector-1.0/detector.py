# -*- coding: utf-8 -*-

############################
###      CREATED BY     ####
### © Azat Zakirov, 2022 ###
############################

from app import create_app
from config_run import host, port
import asyncio
import threading
import os
import socket
import requests


# Создаем экземпляр приложения.
app = create_app()

def get_curl():
    requests.get(f"http://{host}:{port}/detector/status?type=start")
timer = threading.Timer(1, get_curl)
timer.start()

if __name__ == '__main__':
    status=0
    if os.path.exists(f'{app.config.get("ASTERISK_RECORDING_PATH")}{app.config.get("ARI_DIR_RECORD")}/before/'):
        pass
    else:
        os.makedirs(f'{app.config.get("ASTERISK_RECORDING_PATH")}{app.config.get("ARI_DIR_RECORD")}/before/');
        if os.path.exists(f'{app.config.get("ASTERISK_RECORDING_PATH")}{app.config.get("ARI_DIR_RECORD")}/before/'):
            pass
        else:
            app.logger.info(f'Failed to make directory {app.config.get("ASTERISK_RECORDING_PATH")}{app.config.get("ARI_DIR_RECORD")}/before/.')
            status=1
    if os.path.exists(f'{app.config.get("ASTERISK_RECORDING_PATH")}{app.config.get("ARI_DIR_RECORD")}/after/'):
        pass
    else:
        os.makedirs(f'{app.config.get("ASTERISK_RECORDING_PATH")}{app.config.get("ARI_DIR_RECORD")}/after/');
        if os.path.exists(f'{app.config.get("ASTERISK_RECORDING_PATH")}{app.config.get("ARI_DIR_RECORD")}/after/'):
            pass
        else:
            app.logger.info(f'Failed to make directory {app.config.get("ASTERISK_RECORDING_PATH")}{app.config.get("ARI_DIR_RECORD")}/after/.')
            status=1
    if status==1:
        app.logger.info(f'Server was not started')
    else:
        app.logger.info(f'Server is starting')
        app.run(
            host=host,
            port=port,
        )
